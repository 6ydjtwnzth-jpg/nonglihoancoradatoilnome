---
name: level-check
description: Validate and verify levels. Use whenever a level file changes or a physics parameter changes.
---
1. Run `npm run levels:check` (schema validation + headless solver + replay).
2. For each failing level: print the reason (unsolvable, ink too low, hazard unfair).
3. Report minimum ink found vs the level limit, and the score a perfect solution earns.
4. If physics parameters changed, re-run all levels and list levels whose minimum ink changed by more than 10%.
5. Never loosen a limit to make a level pass without telling the author.

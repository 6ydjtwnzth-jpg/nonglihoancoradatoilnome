---
name: art-review
description: Visual review checklist for Percorso. Use after any change to rendering, theme tokens, icons, backgrounds, particles or motion.
---
1. Run the screenshot script for both worlds at 390x844 and 360x740.
2. Check luminous hierarchy: ball > drawn lines > goal > hazards > obstacles > background.
3. Check the background never competes: decorations are subtle, slow, low contrast.
4. Check consistency: stroke widths, corner radii, glow strength, icon style, easing curves, all from tokens.
5. Check contrast of text/numbers and icons; hazards readable without color (shape, motion).
6. Check reduced-motion mode.
7. Verdict + prioritized token-level fixes. Attach screenshots.

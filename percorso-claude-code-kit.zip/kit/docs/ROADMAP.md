# Roadmap

Ogni fase ha **criteri di uscita**: non si passa alla successiva senza. L'arte e la UX non sono fasi finali: guidano dall'inizio.

## Fase 0 — Visione, arte e UX (1-2 settimane)
- Ricerca di riferimenti, 3 style tile per mondo, scelta dell'autore. Tokens, icone, tipografia, motion principles.
- Wireflow di tutti i flussi, prototipo cliccabile della UX di base.
- Decisioni architetturali (ADR). Scaffolding del repo, CI, lint, test.
- **Uscita:** direzione artistica e UX approvate; vertical slice grafica di un livello su carta/HTML.

## Fase 1 — Core engine (2-3 settimane)
- Ricostruire fisica a passo fisso in TypeScript con test (rotolamento, rimbalzi, forme, mine, barre mobili).
- Input di disegno a latenza minima; misura del feel su dispositivi reali.
- **Uscita:** 60 fps su telefono medio, test di fisica verdi, tratto senza ritardo percepibile.

## Fase 2 — Livelli e validatore (2-3 settimane)
- Schema, loader, level editor, solver headless, replay di riferimento.
- Riprogettare i 40 livelli a mano con difficoltà misurata e verificata.
- **Uscita:** `levels:check` verde: ogni livello risolvibile, curva di difficoltà documentata.

## Fase 3 — Produzione artistica e audio (3-4 settimane)
- Implementare la direzione artistica finale: rendering dei due mondi, decorazioni, particelle, trasformazioni di forma, momenti chiave.
- Motore musicale e SFX con mixaggio; aptica.
- **Uscita:** vertical slice completo (3 livelli per mondo) approvato dall'autore; budget prestazioni rispettato.

## Fase 4 — UX polish e accessibilità (2 settimane)
- Onboarding senza testo, menu, impostazioni, ripresa, stati di errore/vuoto, accessibilità, orientamento verticale.
- **Uscita:** playtest con 5 persone: primo livello superato da tutti senza aiuto; nessun punto di confusione critico.

## Fase 5 — Packaging e qualità (2 settimane)
- PWA offline, Capacitor iOS/Android, icone/splash, store art, test su dispositivi reali, audit Lighthouse/a11y.
- **Uscita:** build installabile, nessun crash noto, avvio < 2 s.

## Fase 6 — Beta chiusa (2-3 settimane)
- Telemetria privacy-first opt-in, bilanciamento di difficoltà e inchiostro dai dati, correzione attriti.
- **Uscita:** retention e curva di tentativi sani; lista bug P0/P1 vuota.

## Fase 7 — Lancio e dopo
- Landing page (robots/SEO), pagina store, press kit, piano di aggiornamenti: nuovi mondi, sfide giornaliere, editor di livelli per la community.

## Rischi principali
Livelli non risolvibili · feel dell'input · prestazioni di glow/particelle su telefoni vecchi · direzione artistica poco coerente tra mondi · difficoltà non calibrata · restrizioni audio/sensori su iOS.

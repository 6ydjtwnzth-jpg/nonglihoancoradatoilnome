# Architettura (proposta, da validare in plan mode)

## Stack consigliato
- **TypeScript + Vite**, rendering **Canvas 2D** a livelli (valutare WebGL/PixiJS solo se il budget di glow/particelle lo richiede: misurare prima).
- **Engine fisico proprio** (cerchio vs segmenti, passo fisso 1/480 s): già dimostrato nel prototipo; ricostruirlo con test. Non adottare Matter.js senza un motivo misurabile (controllo, determinismo, peso).
- **Web Audio** diretto (sintesi + sample opzionali); layer musicale e layer SFX separati con bus e ducking.
- **PWA** (manifest, service worker, offline) → poi **Capacitor** per iOS/Android (haptics, store, orientamento, sensori).
- Test: **Vitest** (fisica, validazione, solver), **Playwright** (e2e + screenshot visivi mobile), Lighthouse per le prestazioni.
- Qualità: ESLint, Prettier, `tsc --noEmit` in CI, GitHub Actions.

## Struttura cartelle
```
src/
  engine/        fisica, collisioni, passo fisso, forme, eventi (puro, senza DOM)
  levels/        schema (zod), dati livelli (JSON), loader, validatore
  game/          stato partita, regole, punteggio, mine/barre/quadratini
  render/        livelli di canvas: sfondo, decorazioni, mondo, effetti, UI overlay
  theme/         tokens.ts, palette per mondo, easing
  audio/         motore, progressioni, one-shot, mixer
  input/         disegno (pointer), sensori (tilt), aptica
  ui/            HUD, menu, impostazioni, icone (SVG)
  state/         store, persistenza (interfaccia Storage), migrazioni
  tools/         level editor, solver, replay, styleguide
public/          manifest, icone, robots.txt
tests/           unit, e2e, visual
docs/            documenti di progetto
```

## Livelli come dati + validatore (il pezzo critico)
- Schema unico: muri, quadratini, mine, barre mobili, A, B, inchiostro, forme, mondo, difficoltà.
- **Campo di gioco a proporzione fissa** (es. 9:16 con letterbox), coordinate in unità logiche, non in frazioni dello schermo.
- **Solver headless** (`levels:check`): per ogni livello cerca una soluzione entro il limite d'inchiostro (ricerca su rampe candidate, simulazione deterministica) e produce un "replay" di riferimento. Un livello senza soluzione fa fallire la CI.
- **Level editor** interno (tools/): disegno dei livelli a schermo, anteprima, test del solver, esportazione JSON. I livelli finali vanno rifiniti a mano, non generati.
- Curva di difficoltà misurata (inchiostro minimo, numero di ostacoli, tentativi dei tester), non intuita.

## Rendering e prestazioni
- Livelli separati e ridisegnati solo se servono; sfondo e decorazioni in canvas dedicato a risoluzione ridotta.
- Alone/glow a budget (shadowBlur costoso): pre-render su sprite o gradienti.
- Pool di particelle, nessuna allocazione nel frame loop, DPR limitato (max 2-3).
- Telemetria interna di frame time; modalità "qualità bassa" automatica se i frame calano.

## Audio
- Contesto avviato dal primo gesto; ripresa/sospensione con visibilità pagina.
- Musica generativa: banca di progressioni in Re maggiore, transizioni a fine battuta, one-shot casuali (gocce di legno) con rate limiting.
- Mixer: master, musica, SFX, riverbero condiviso; ducking su vittoria/sconfitta.

## Robots.txt e SEO (se pubblicato sul web)
- `public/robots.txt` incluso nel kit. Landing page indicizzabile, `og:` tag e anteprima social curati; il gioco in sé è l'app.
- Se si pubblica anche una API/analytics, escluderla da `robots.txt` e documentarla.

## Decisioni da prendere presto (ADR in `docs/adr/`)
Rendering Canvas vs WebGL · engine proprio vs libreria · PWA-only vs store (Capacitor) · monetizzazione (nessuna? premium? mondi a pagamento?) · analytics e privacy · localizzazione.

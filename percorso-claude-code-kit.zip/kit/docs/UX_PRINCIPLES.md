# UX — principi e requisiti

## Principi
1. **Il dito è il gioco.** Disegnare deve essere immediato, preciso e a latenza minima. Se il tratto è in ritardo, tutto il resto non conta.
2. **Zero attrito.** Dal tocco su "icona" alla prima partita: meno di 5 secondi. Niente schermate di benvenuto, niente tutorial a muro.
3. **Insegnare giocando.** Il livello 1 spiega tutto con gesti animati e un esempio, senza parole. Ogni nuova meccanica (quadratini, mine, barre, forme) ha un livello "didattico" dedicato.
4. **Perdonare sempre.** Annulla, Cancella, Riparti: un tocco, istantanei, senza conferme (tranne le azioni distruttive: restart totale).
5. **Feedback immediato e leggibile:** ogni azione ha una risposta visiva, sonora e (dove disponibile) aptica entro 100 ms.
6. **Pollice prima di tutto.** Comandi principali in basso nella zona raggiungibile; zone sicure per notch e barre di sistema; target ≥ 44 px.
7. **Niente testo non necessario.** Icone chiare con `aria-label`; numeri solo dove servono.
8. **Controllo dell'utente:** audio, vibrazione e movimento sempre regolabili in un punto unico (impostazioni).
9. **Calma:** nessuna notifica aggressiva, nessun timer di pressione, nessuna dark pattern. Il tono è quello del mood.

## Flussi da progettare (wireflow in `docs/flows/`)
- Primo avvio e onboarding · livello (disegno → corsa → esito) · vittoria/sconfitta · cambio mondo · menu (restart, selezione livelli per mondo) · impostazioni · ripresa dopo interruzione (chiamata, app in background) · permessi sensori (iOS) spiegati con gesto, non con popup freddo.

## Requisiti concreti
- Input: Pointer Events, `touch-action:none`, eventi coalescenti/predittivi, campionamento ≤ 4 px, nessun jank. Rifiuto del palm rejection a bordo schermo.
- Prestazioni: 60 fps sostenuti su un telefono di fascia media; tempo di avvio < 2 s; offline completo (PWA).
- Stati vuoti, errore e caricamento progettati (anche se sono quasi invisibili).
- Salvataggio automatico di livello, punteggi, impostazioni; recupero dopo chiusura brusca.
- **Accessibilità:** `prefers-reduced-motion`, contrasto, palette per daltonici, alternative non sonore, aptica opzionale, supporto a una mano, dimensioni regolabili dell'inchiostro/pallina valutate come opzione di assistenza.
- Orientamento: **verticale** (il prototipo in orizzontale non funzionava). Decidere se supportare l'orizzontale solo dopo la prima versione.

## Come si misura
- Playtest con 5 persone per ciclo, senza istruzioni, registrando: tempo al primo livello superato, tentativi per livello, abbandoni, punti di confusione.
- Metriche di prodotto (privacy-first, opt-in): D1/D7 retention, livello medio raggiunto, curva di tentativi, uso di Annulla/Cancella, crash e frame drop.
- Ogni fase della roadmap chiude con un playtest e una lista di attriti risolti.

# Game design — cosa fa il prototipo oggi (da preservare o migliorare consapevolmente)

## Regole
- La pallina parte da A (in alto a sinistra, ~14% larghezza, 12% altezza), cade e raggiunge B (anello pulsante) a distanza < 20 px.
- Si disegna col dito prima o durante la corsa. Comandi: Via/Riparti, Annulla (ultima linea), Cancella (tutto).
- Inchiostro limitato per livello. Punti = `clamp(round(100·(1 − usato/limite)), 1, 100)`; conta il migliore per livello; totale in basso a destra.
- 40 livelli: 20 space (indice 0-19), 20 lava (20-39). Menu: restart con doppio tap di conferma, selezione dei livelli sbloccati divisa per mondo.

## Elementi di livello
- **Muri fissi** (segmenti, spessore 8 px). **Quadratini** distruttibili al primo tocco.
- **Mine** fluttuanti: al tocco esplodono e spingono via la pallina (~720 px/s) con particelle.
- **Barre mobili**: oscillano e spingono davvero la pallina (contatto con velocità relativa).
- **Forme della pallina**: cerchio, quadrato, esagono, ottagono, stella, dodecagono; cambia a ogni urto (cooldown 0.3 s). Collide come cerchio ma con raggio, rimbalzo, attrito e resistenza al rotolamento diversi.

## Fisica (valori del prototipo, da tarare nel nuovo engine)
- Passo fisso 1/480 s · G = 1700 px/s² · raggio base 11 px · spessore linea 4 px.
- Contatto cerchio-segmento con correzione di penetrazione, restituzione (sotto 80 px/s non rimbalza), attrito di Coulomb con rotolamento reale (disco, impulso tangenziale ÷3), rotazione angolare.
- Forme: circle r11 e.30 μ.6 rr0 · hexagon r12 e.20 μ.9 rr1.4 · octagon r12 e.50 μ.7 rr.6 · star r14 e.15 μ.9 rr2.2 · dodecagon r12 e.35 μ.65 rr.25 · square r12 e.25 μ.8 rr1.

## Problemi noti del prototipo (da risolvere, non nascondere)
- Quasi tutti i livelli **non sono verificati come risolvibili** con l'inchiostro dato: serve un solver/validatore.
- I livelli sono in frazioni di schermo: cambiando proporzioni cambia la difficoltà. Va definito un campo di gioco a proporzione controllata.
- Il tilt degli sfondi non funziona in iframe/anteprime; su iOS richiede il permesso da un gesto.
- La musica è un'approssimazione sintetizzata (Web Audio) di un pad "fragile hearts", non usa Synplant.
- Mine e barre sono posizionate in modo semi-casuale: vanno rifinite a mano, livello per livello.
- Pochi tester reali: la curva di difficoltà è un'ipotesi.

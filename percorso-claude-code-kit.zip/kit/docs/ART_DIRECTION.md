# Direzione artistica — DA DEFINIRE (questo è il documento più importante)

Obiettivo: un gioco che sembri un oggetto d'autore, non un prototipo. L'arte guida il gioco, non lo decora.
**Regola per Claude Code:** non scrivere UI finale finché questo documento non ha una direzione approvata dall'autore.

## Cosa è già deciso (dal prototipo)
- **Mood:** dreamy, quieto, notturno, morbido. Pochi elementi, molto spazio vuoto, luce che respira.
- **Gameplay in primo piano:** pallina e linee sono sempre l'elemento più luminoso e nitido; tutto il resto sta dietro.
- **Interfaccia:** solo icone, vetro smerigliato, bordi sottili, nessun testo (numeri a parte).
- **Mondo SPACE:** sfondo #1a1b26, linee #fffff0 con alone lilla, pallina #fffb69, mine #ff9ec7, barre mobili #ffc9ec, stelle, lucciole, filamenti lilla.
- **Mondo LAVA:** sfondo #1d1118 con luce di lava dal basso, linee #fff1e4 con alone arancio, pallina #ffd36b, mine #ff5f6d, braci che salgono, filamenti rosa-corallo.
- **Suono:** pad in Re maggiore, progressioni lente con release lunga, "gocce di legno" riverberate. Riferimento sonoro: Synplant 2, preset "Fragile Hearts".

## Cosa va definito (fase 0 — prima di costruire)
Per ogni punto: 3 opzioni visuali (style tile in HTML, schermata mobile 390x844), poi scelta dell'autore.
1. **Linguaggio di forma:** linee morbide con bordi arrotondati? Tratto "a pennarello di luce"? Texture o piatto?
2. **Materia della luce:** glow additivo, bagliore volumetrico, grana. Budget di glow per schermata (prestazioni).
3. **Tipografia:** anche senza testo servono numeri (livello, punti): un solo font, cifre tabulari, pesi.
4. **Iconografia:** set di icone proprietario coerente (spessore tratto, angoli, metafore) per tutti i comandi.
5. **Palette completa e semantica:** non solo i colori attuali; ruoli (pericolo, obiettivo, inchiostro, successo), versione per daltonismo, contrasto WCAG.
6. **Mondi:** SPACE e LAVA sono i primi due. Definire la regola per creare mondi futuri (es. oceano, foresta di cristalli) così restano della stessa famiglia.
7. **Personaggio della pallina:** forma, bagliore, scia, "respiro". Le trasformazioni di forma sono un momento di personalità: come si animano?
8. **Moto e ritmo:** curve di easing, durate, regole di "overshoot", cosa pulsa e a che velocità. Un solo respiro di riferimento (es. 4 s).
9. **Particelle e decorazioni di sfondo:** lucciole, polvere, filamenti: densità massima, velocità massima, mai in conflitto con il gioco.
10. **Momenti chiave:** inizio livello, vittoria, sconfitta, cambio mondo, sblocco: coreografia visiva + sonora per ciascuno (breve, elegante, saltabile).
11. **Schermata iniziale / app icon / splash / store art:** coerenti con il gioco.
12. **Audio direction:** palette timbrica, regole armoniche (Re maggiore), dinamica, ducking durante la vittoria, silenzi.

## Principi guida
- **Sottrarre:** se un elemento non migliora la lettura o l'emozione, si toglie.
- **Gerarchia luminosa:** pallina > linee disegnate > obiettivo > pericoli > ostacoli > sfondo.
- **Pericolo leggibile senza testo:** forma e movimento, non solo colore.
- **Coerenza tra mondi:** cambia la palette e la materia, non il linguaggio.
- **Il vuoto è un asset.** Lo sfondo non deve mai competere con il gameplay.

## Deliverable richiesti a Claude Code per chiudere la fase artistica
- 3 style tile per mondo (HTML statico), moodboard con riferimenti, scelta motivata.
- `src/theme/tokens.ts` con colori, spazi, raggi, ombre/alone, durate e easing.
- Pagina `/styleguide` con icone, pulsanti, stati, particelle, palette e prove di contrasto.
- Prototipo di un livello "vertical slice" con arte finale + audio, da far approvare.
